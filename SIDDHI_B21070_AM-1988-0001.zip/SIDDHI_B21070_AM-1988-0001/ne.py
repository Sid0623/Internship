# -*- coding: utf-8 -*-
"""
Created on Mon Dec 11 15:56:39 2023

@author: 91945
"""

import numpy as np
import matplotlib.pyplot as plt
import csv

# Load earthquake amplitude values from the text file
amplitude_values = np.loadtxt('ne.txt')

# Sample rate (you may need to adjust this based on your data)
sample_rate = 200 # for simplicity, assuming one sample per unit of time

# Compute the Fast Fourier Transform (FFT)
fft_result = np.fft.fft(amplitude_values)
frequencies = np.fft.fftfreq(len(fft_result), d=1/sample_rate)

# Exclude the negative frequencies (since the signal is real)
positive_frequencies = frequencies[:len(frequencies)//2]
positive_fft_result = fft_result[:len(frequencies)//2]

# Find the corresponding frequency with the maximum amplitude
dominant_frequency = positive_frequencies[np.argmax(np.abs(positive_fft_result))]

# Plot the amplitude and frequency data
plt.subplot(2, 1, 1)
plt.plot(amplitude_values, 'r-', label='Amplitude')
plt.title('Earthquake Amplitude Data')
plt.xlabel('Time')
plt.ylabel('Amplitude')
plt.legend()

plt.subplot(2,1,2)
plt.plot(positive_frequencies, np.abs(positive_fft_result), 'b-', label='FFT')
plt.title('Frequency Domain Representation')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude')
plt.axvline(dominant_frequency, color='g', linestyle='--', label='Dominant Frequency')
plt.legend()

plt.show()
# Create a CSV file with amplitude and corresponding frequencies
output_data = zip(amplitude_values, positive_frequencies)
output_file = 'amplitude_frequency_data_ne.csv'

with open(output_file, 'w', newline='') as csvfile:
    csv_writer = csv.writer(csvfile)
    csv_writer.writerow(['Amplitude', 'Frequency'])
    csv_writer.writerows(output_data)

print(f"CSV file '{output_file}' created with amplitude and corresponding frequencies.")








